Changelog
=========

### `v0.0.2` 2014-08-25

 * Feature: List contents of archive: `Zip.list`.
 * Feature: Test integrity of archive: `Zip.test`.

### `v0.0.1` 2014-08-25

 * Initial release.
 * Feature: Extract with full paths: `Zip.extractFull`
 * Feature: Extract: `Zip.extract`.

> Dates are in *ISO 8601* format (year-month-day)
